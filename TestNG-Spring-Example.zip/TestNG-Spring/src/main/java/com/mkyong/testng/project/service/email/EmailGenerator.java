package com.mkyong.testng.project.service.email;

public interface EmailGenerator {

	String generate();
	
}